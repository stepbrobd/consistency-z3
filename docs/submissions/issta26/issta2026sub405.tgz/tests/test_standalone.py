import z3

from consistency.common import check, cleanup
from consistency.model.causal_consistency import CausalConsistency
from consistency.model.linearizability import Linearizability
from consistency.model.model import Model
from consistency.model.monotonic_reads import MonotonicReads
from consistency.model.monotonic_writes import MonotonicWrites
from consistency.model.pram_consistency import PRAMConsistency
from consistency.model.read_your_writes import ReadYourWrites
from consistency.model.writes_follow_reads import WritesFollowReads
from consistency.relation import Relation


@cleanup
def test_standalone() -> None:
    models: list[type[Model]] = [
        CausalConsistency,
        Linearizability,
        MonotonicReads,
        MonotonicWrites,
        PRAMConsistency,
        ReadYourWrites,
        WritesFollowReads,
    ]

    for m in models:
        assert check(m.assertions())
        Relation.Reset()
        z3.reset_params()
